
public class Projectile extends MySprite {
	public Projectile() {
		
		super(0, 0, "Rock2.png", 100, 100);
	}
}