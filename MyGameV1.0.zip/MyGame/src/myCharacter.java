import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class myCharacter extends MySprite implements Runnable{
	
	private int direction;
	private int prevdirection;
	private int AniFrame;
	private Thread moveThread;
	private JLabel framedisplay;
	
	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}
	public int getprevdirection() {
		return prevdirection;
	}

	public void setprevdirection(int prevdirection) {
		this.prevdirection = prevdirection;
	}
	
	public myCharacter(String filename, JLabel framedisplay){
		//retrieve graphics from bin folder
		super(0, 0, filename, 100, 100);
		this.AniFrame = 0;
		this.framedisplay = framedisplay;
		
	}
	public void startThread() {
		moveThread = new Thread(this, "startCharacter");
		moveThread.start();
	}

	@Override
	public void run() {
		while(true) {
		// TODO Auto-generated method stub
			try {
				Thread.sleep(120);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//facing right idle
			if(direction == 0) {
				//position of the first frame i need to get
				this.prevdirection = 0;
				this.setFrame(AniFrame, 0);
				
				this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
				this.AniFrame+=1;
					if(AniFrame > 3) {
						AniFrame = 0;
					}
			}
			//moving right
			if(direction == 1) {
				//position of the first frame i need to get
				//count it from 0 - top left on sprite sheet is 0  0
				this.prevdirection = 0;
				this.setFrame(AniFrame, 2);
				
				this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
				this.AniFrame+=1;
					if(AniFrame > 5) {
						AniFrame = 0;
					}
			}
			//moving left
			if(direction == 2) {
				//position of the first frame i need to get
				//count it from 0 - top left on sprite sheet is 0  0
				this.prevdirection = 3;
				this.setFrame(AniFrame, 3);
				
				this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
				this.AniFrame+=1;
					if(AniFrame > 5) {
						AniFrame = 0;
					}
			}
			//facing left idle
			if(direction == 3) {
				//position of the first frame i need to get
				//count it from 0 - top left on sprite sheet is 0  0
				this.prevdirection = 3;
				this.setFrame(AniFrame, 1);
				
				this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
				this.AniFrame+=1;
					if(AniFrame > 3) {
						AniFrame = 0;
					}
			}
			//up or down
			if(direction == 4 || direction == 5) {
				//position of the first frame i need to get
				//count it from 0 - top left on sprite sheet is 0  0
				if(prevdirection == 0) {
					this.setFrame(AniFrame, 2);
					this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
					this.AniFrame+=1;
						if(AniFrame > 5) {
							AniFrame = 0;
						}
				}else if(prevdirection == 3) {
					this.setFrame(AniFrame, 3);
					this.framedisplay.setIcon(new ImageIcon(this.getFrame()));
					this.AniFrame+=1;
						if(AniFrame > 5) {
							AniFrame = 0;
						}
					}
				
				}
			
			
			}
		}

}
