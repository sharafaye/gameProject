import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class GamePrepProject extends JFrame implements KeyListener, ActionListener {
	
	//get the sprite working on the screen -- declare it 
	
	private myCharacter Player;
	
	private ImageIcon PlayerImage;
	private JLabel PlayerLabel;
	
	private MProjectile HeartBullet;
	private ImageIcon HeartImage;
	private JLabel HeartLabel;
	
	private Image BackGround;
	private JFrame frame;
	
	//if you want a click listener, you have to add a container
	
	private Container content;
	
	public GamePrepProject() {
		super("Journey of the Jelly Bean Bear");
		
		try {
            BackGround = ImageIO.read(new File("bin/grass.png"));
            // Set background image
            this.setContentPane(new JLabel(new ImageIcon(BackGround)));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		setSize(Propreties.SCREEN_WIDTH, Propreties.SCREEN_HEIGHT);
		content = getContentPane();
		
		PlayerLabel = new JLabel();
		Player = new myCharacter("Pink_Sheet.png", PlayerLabel);
		
		Player.setSpriteX(450);
		Player.setSpriteY(350);
		PlayerLabel.setIcon(new ImageIcon(Player.getFrame()));
		PlayerLabel.setSize(Player.getSpriteW(), Player.getSpriteH());
		PlayerLabel.setLocation(Player.getSpriteX(), Player.getSpriteY());
		content.add(PlayerLabel);
		//Player.setDirection(0);
		Player.startThread();
		PlayerLabel.setFocusable(false);
		
		HeartBullet = new MProjectile();
		HeartBullet.setFilename("Rock2.png");
		HeartLabel = new JLabel();
		
		HeartImage = new ImageIcon(getClass().getResource(HeartBullet.getFilename() ) );
		HeartBullet.setHeartLabel(HeartLabel);
		

		HeartBullet.setSpriteX(0);
		HeartBullet.setSpriteY(0);
		HeartBullet.setPlayer(Player);
		HeartLabel.setIcon(HeartImage);
		HeartLabel.setSize(HeartBullet.getSpriteW(), HeartBullet.getSpriteH());
		HeartLabel.setLocation(HeartBullet.getSpriteX(), HeartBullet.getSpriteY());
		content.add(HeartLabel);
		HeartLabel.setVisible(false);
		HeartBullet.hide();
		
		HeartLabel.setFocusable(false);
		
		
		content.addKeyListener(this);
		content.setFocusable(true);
		
		setVisible(true);
		
		frame = new JFrame();
		JOptionPane.showMessageDialog(frame, "Welcome to Journey of the Jelly Bean Bear! press WASD to move and space bar to shoot. "
										   + "Kill as many enemies as you can!", 
											 "Welcome!", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("bin/Pink_Monster.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[]args) {
		GamePrepProject myGame = new GamePrepProject();
		myGame.setVisible(true);
		
		String filepath = "BackgroundMusic.wav";
		BkgMusic musicObject = new BkgMusic();
		musicObject.playMusic(filepath);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		//Player.setDirection(0);
		// TODO Auto-generated method stub
		//get the doctors current position 
		int x = Player.getSpriteX();
		int y = Player.getSpriteY();
		//if up key pressed, move up
		if(e.getKeyCode() == KeyEvent.VK_W) {
			Player.setDirection(4);
			y -= Propreties.CHARACTER_STEP;
			if(y + Player.getSpriteH() < 0 ) {
				y = Propreties.SCREEN_HEIGHT;
				
			}
		}
		//if down key pressed, move down
		if(e.getKeyCode() == KeyEvent.VK_S) {
			Player.setDirection(5);
			y += Propreties.CHARACTER_STEP;
			if(y > Propreties.SCREEN_HEIGHT ) {
				y = -1 * Player.getSpriteH();
			}
			
		}
		//if left key pressed, move left
		if(e.getKeyCode() == KeyEvent.VK_A) {
			Player.setDirection(2);
			x -= Propreties.CHARACTER_STEP;
			if(x + Player.getSpriteW() < 0 ) {
				x = Propreties.SCREEN_WIDTH;
				
			}
		}
		//if right key pressed, move right
		if(e.getKeyCode() == KeyEvent.VK_D) {
			Player.setDirection(1);
			x += Propreties.CHARACTER_STEP;
			if(x > Propreties.SCREEN_WIDTH ) {
				x = -1 * Player.getSpriteW();
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			
			if(!HeartBullet.getMoving()) {
				
				HeartBullet.setSpriteX(Player.getSpriteX());
				HeartBullet.setSpriteY(Player.getSpriteY());
				HeartBullet.setDirection(1);
				HeartBullet.moveProjectile();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			if(!HeartBullet.getMoving()) {
				
				HeartBullet.setSpriteX(Player.getSpriteX());
				HeartBullet.setSpriteY(Player.getSpriteY());
				HeartBullet.setDirection(2);
				HeartBullet.moveProjectile();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			if(!HeartBullet.getMoving()) {
				
				HeartBullet.setSpriteX(Player.getSpriteX());
				HeartBullet.setSpriteY(Player.getSpriteY());
				HeartBullet.setDirection(4);
				HeartBullet.moveProjectile();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_DOWN) {
			if(!HeartBullet.getMoving()) {
				
				HeartBullet.setSpriteX(Player.getSpriteX());
				HeartBullet.setSpriteY(Player.getSpriteY());
				HeartBullet.setDirection(5);
				HeartBullet.moveProjectile();
			}
		}
		
		Player.setSpriteX(x);
		Player.setSpriteY(y);
		
		PlayerLabel.setLocation(Player.getSpriteX(), Player.getSpriteY());
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		Player.setDirection(Player.getprevdirection());
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
			}

		
	}
