import javax.swing.JButton;
import javax.swing.JLabel;

public class MProjectile extends MySprite2 implements Runnable{
	
	private int direction;
	private Boolean visible;
	private Boolean moving;
	private JLabel HeartLabel;
	private myCharacter Player;
	
	private Thread t1;
	
	public void setHeartLabel(JLabel temp) {
		HeartLabel = temp;
	}
	public void setPlayer(myCharacter temp) {
		Player = temp;
	}
	
	//getters and setters
	
	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}
	
	public Boolean getMoving() {
		return moving;
	}
	public void setMoving(Boolean moving) {
		this.moving = moving;
	}
	
	//default constructor
	
	public MProjectile() {
		
		super(0, 0, "Rock2.png", 24, 24);
		this.moving = false; this.visible = true;
		
	}
	
	//show and hide functions to call in code
	
	public void hide() {
		this.visible = false;
		
	}
	public void show() {
		this.visible = true;
		
	}
	
	public void Display() {
		System.out.println("X, Y: " + this.spriteX + ", " + this.spriteY + " / v: " + this.visible + " / m: "+ this.moving);
	}
	
	public void moveProjectile() {
		//animate
		if (!this.moving) {
			t1 = new Thread(this, "Move Heart");
			t1.start();		
		}
	}
	
	public void stopProjectile() {
		this.moving = false;
	}
	
	//collision functionhere
	
	@Override
	public void run() {
		this.moving = true;
		this.HeartLabel.setVisible(true);
		while(moving) {
			
			try {
				Thread.sleep(60);
			}catch (Exception e) {
				e.printStackTrace();
			}
			//increace x by character step
			int x = Player.getSpriteX();
			int y = Player.getSpriteY();
			
			if(direction == 1) {
				x = this.spriteX + Propreties.CHARACTER_STEP * 4;
				//boundary check
				if( x > Propreties.SCREEN_WIDTH) {
					this.visible = false;
					this.moving = false;
					HeartLabel.setVisible(false);	
				}
				this.setSpriteX(x);
				HeartLabel.setLocation(this.spriteX, this.spriteY);
			
			} 
			
			if(direction == 2) {
				
				x -= this.spriteX + Propreties.CHARACTER_STEP * 4;
				//boundary check
				if( x < Propreties.SCREEN_WIDTH) {
					this.visible = false;
					this.moving = false;
					HeartLabel.setVisible(false);		
				}
				this.setSpriteX(x);
				HeartLabel.setLocation(this.spriteX, this.spriteY);
			} 
			
			if(direction == 4) {
				
				y -= this.spriteY + Propreties.CHARACTER_STEP * 4;
				
				if(y < Propreties.SCREEN_HEIGHT) {
					this.moving = false;
					this.visible = false;
					HeartLabel.setVisible(false);
				}
				this.setSpriteY(y);
				HeartLabel.setLocation(this.spriteX, this.spriteY);
			}
			
			if(direction == 5) {
				
				y = this.spriteY + Propreties.CHARACTER_STEP * 4;
				
				if(y > Propreties.SCREEN_HEIGHT) {
					this.moving = false;
					this.visible = false;
					HeartLabel.setVisible(false);
				}
				this.setSpriteY(y);
				HeartLabel.setLocation(this.spriteX, this.spriteY);
			}
			
			
			
			//this.detectCollision();
			
			
			//update label position
			
		}
	}

}
