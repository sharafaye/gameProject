import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class Projectile extends MySprite2 {
	
	private Boolean visible;
	private Boolean moving;
	
	private MProjectile HeartBullet;
	private ImageIcon HeartImage;
	private JLabel HeartLabel;
	
	//getters and setters
	
	public Boolean getMoving() {
		return moving;
	}
	public void setMoving(Boolean moving) {
		this.moving = moving;
	}
	
	//default constructor
	public Projectile() {
		
	}
	
	public Projectile(int PlayerDirection, int spriteX, int spriteY, String filename) {
		
		super(spriteX + 32, spriteY + 32, filename, 24, 24);
		System.out.println("sprite");  
		this.moving = false;
		
	}
	
	public void Display() {
		System.out.println("X, Y: " + this.spriteX + ", " + this.spriteY + " / v: " + this.visible + " / m: "+ this.moving);
	}
}