import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GamePrepProject extends JFrame implements KeyListener, ActionListener {
	
	//get the sprite working on the screen -- declare it 
	
	private myCharacter Player;
	
	private ImageIcon PlayerImage;
	private JLabel PlayerLabel;
	
	
	
	//if you want a click listener, you have to add a container
	
	private Container content;
	
	public GamePrepProject() {
		super("Dungeon Crawl!");
		setSize(Propreties.SCREEN_WIDTH, Propreties.SCREEN_HEIGHT);
		content = getContentPane();
		content.setBackground(Color.darkGray);
		setLayout(null);
		
		PlayerLabel = new JLabel();
		Player = new myCharacter("Pink_Sheet.png", PlayerLabel);
		
		Player.setSpriteX(375);
		Player.setSpriteY(250);
		PlayerLabel.setIcon(new ImageIcon(Player.getFrame()));
		PlayerLabel.setSize(Player.getSpriteW(), Player.getSpriteH());
		PlayerLabel.setLocation(Player.getSpriteX(), Player.getSpriteY());
		content.add(PlayerLabel);
		//Player.setDirection(0);
		Player.startThread();
		PlayerLabel.setFocusable(false);
		
		
		
		content.addKeyListener(this);
		content.setFocusable(true);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[]args) {
		GamePrepProject myGame = new GamePrepProject();
		myGame.setVisible(true);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		//Player.setDirection(0);
		// TODO Auto-generated method stub
		//get the doctors current position 
		int x = Player.getSpriteX();
		int y = Player.getSpriteY();
		//if up key pressed, move up
		if(e.getKeyCode() == KeyEvent.VK_W) {
			Player.setDirection(4);
			y -= Propreties.CHARACTER_STEP;
			if(y + Player.getSpriteH() < 0 ) {
				y = Propreties.SCREEN_HEIGHT;
				
			}
		}
		//if down key pressed, move down
		if(e.getKeyCode() == KeyEvent.VK_S) {
			Player.setDirection(5);
			y += Propreties.CHARACTER_STEP;
			if(y > Propreties.SCREEN_HEIGHT ) {
				y = -1 * Player.getSpriteH();
			}
			
		}
		//if left key pressed, move left
		if(e.getKeyCode() == KeyEvent.VK_A) {
			Player.setDirection(2);
			x -= Propreties.CHARACTER_STEP;
			if(x + Player.getSpriteW() < 0 ) {
				x = Propreties.SCREEN_WIDTH;
				
			}
		}
		//if right key pressed, move right
		if(e.getKeyCode() == KeyEvent.VK_D) {
			Player.setDirection(1);
			x += Propreties.CHARACTER_STEP;
			if(x > Propreties.SCREEN_WIDTH ) {
				x = -1 * Player.getSpriteW();
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_SPACE) {
			new Projectile(Player.getDirection(), Player.getSpriteX(), Player.getSpriteY());
		}
		
		
		Player.setSpriteX(x);
		Player.setSpriteY(y);
		
		PlayerLabel.setLocation(Player.getSpriteX(), Player.getSpriteY());
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		Player.setDirection(Player.getprevdirection());
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
			}

		
	}
