import javax.swing.JButton;
import javax.swing.JLabel;

public class MProjectile extends MySprite implements Runnable{
	
	private Boolean visible;
	private Boolean moving;
	private JLabel HeartLabel;
	private myCharacter Player;
	
	private Thread t1;
	
	public void setHeartLabel(JLabel temp) {
		HeartLabel = temp;
	}
	public void setPlayer(myCharacter temp) {
		Player = temp;
	}
	
	//getters and setters
	
	public Boolean getMoving() {
		return moving;
	}
	public void setMoving(Boolean moving) {
		this.moving = moving;
	}
	
	//default constructor
	
	public MProjectile() {
		
		super(0, 0, "Rock2.png", 200, 124);
		this.moving = false; this.visible = true;
		
	}
	
	//show and hide functions to call in code
	
	public void hide() {
		this.visible = false;
		
	}
	public void show() {
		this.visible = true;
		
	}
	
	public void Display() {
		System.out.println("X, Y: " + this.spriteX + ", " + this.spriteY + " / v: " + this.visible + " / m: "+ this.moving);
	}
	
	public void moveProjectile() {
		//animate
		t1 = new Thread(this, "Move Heart");
		t1.start();
	}
	
	public void stopTardis() {
		this.moving = false;
	}
	
	//collision functionhere
	
	@Override
	public void run() {
		this.moving = true;
		while(moving) {
			
			//increace x by character step
			int x = this.spriteX + Propreties.CHARACTER_STEP * 2;
			
			//boundary check
			if( x > Propreties.SCREEN_WIDTH) {
				x = -1 * this.spriteW;
				
			}
			
			//update stored state
			//this.spriteX = x;
			this.setSpriteX(x);
			//this.detectCollision();
			
			//update label position
			HeartLabel.setLocation(this.spriteX, this.spriteY);
			
			//pause
			try {
				Thread.sleep(200);
			}catch (Exception e) {
				
			}
		}
	}

}
